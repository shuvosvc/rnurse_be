const member_id="1";

if (!(Number.isInteger(+member_id) && +member_id > 0)) {
 console.log("false");
 
}else{
  console.log("true");
  
}